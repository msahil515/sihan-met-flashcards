/* Offline desktop pack: passphrase gate removed (this is your own
   local copy, nothing is served on the network). */
(function(){try{document.documentElement.classList.remove('gate-locked');}catch(e){}})();
