/* offline pack: no update button, nothing to sync */
