/* Offline desktop pack: force-sync / service-worker reload removed
   (no network, nothing to sync). */
(function(){})();
